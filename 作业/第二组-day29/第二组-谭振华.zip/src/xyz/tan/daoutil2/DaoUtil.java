package xyz.tan.daoutil2;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

// 工具类的方法都是静态方法
public class DaoUtil {
	private static String driver;
	private static String url;
	private static String userName;
	private static String password;
	static {
		
		try {
			Properties properties = new Properties();
			InputStream rsm = DaoUtil.class.getClassLoader().getResourceAsStream("jdbc.properties");
			// 将文件流载入Properties
			properties.load(rsm);
			//通过key获取到配置文件的值
			driver = properties.getProperty("jdbc.driver");
			url = properties.getProperty("jdbc.url");
			userName = properties.getProperty("jdbc.userName");
			password = properties.getProperty("jdbc.password");
			//加载驱动
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	// 连接数据库
	public static Connection _1getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	// 释放资源
	public static void close(ResultSet ey, Statement ct, Connection conn) {
		if(ey != null) {
			try {
				ey.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(ct != null) {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	
	
	
	
}
