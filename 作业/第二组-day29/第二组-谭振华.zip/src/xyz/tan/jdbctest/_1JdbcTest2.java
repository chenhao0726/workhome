package xyz.tan.jdbctest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class _1JdbcTest2 {

	public static void main(String[] args) {
		Connection connection = null;
		Statement ct = null;
		// 加连预执释
		try {
			// 加载jdbc
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载 createStatement
			ct = connection.createStatement();
			// id设置自增可以不写
			String sql = "insert into t_user(name,pwd,gender, age) value('ns','12345',0,16)";
			// 执行sql
			ct.executeUpdate(sql);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();			
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}
