package xyz.tan.jdbctest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class _1JDBCTest {

	public static void main(String[] args) {
		Connection connection = null;
		Statement ct = null;
		// 加连预执释
		try {
			// 创建对象
			Driver driver = new Driver();
			// 注册
			DriverManager.registerDriver(driver);
			// 连接数据库
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/day1026", 
					"root", 
					"123456");
			// 创建预执行对象
			ct = connection.createStatement();
			// sql 命令 ( 增删改)
			String sql = "insert into t_user(name,pwd,gender,age) value('zhang','123456',0,18)";
			// 执行sql语句     executeUpdate(传入sql命令字符串);
			ct.executeUpdate(sql);
				
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		
		
		
		
		
		
		
	}

}
