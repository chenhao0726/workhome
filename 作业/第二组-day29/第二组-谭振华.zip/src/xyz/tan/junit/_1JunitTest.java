package xyz.tan.junit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.junit.Test;

//  单元测试
public class _1JunitTest {
	
	
	@Test
	// 插入语句
	public void saveTest() throws Exception {
		// 加连预执释
		Class.forName("com.mysql.jdbc.Driver");
		// 连接
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");	
		// 预计载
		Statement ct = conn.createStatement();
		//  sql命令语句
		String sql = "insert into t_user(name,pwd,gender,age) value('jik','123456',1,19)";
		// 执行语句
		ct.executeUpdate(sql);
	
	}
	// 删除
	@ Test
	public void deleteTest() throws Exception {
		// 加连预执释
		Class.forName("com.mysql.jdbc.Driver");
		// 连接数据库
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
		// 预加载
		Statement ct = conn.createStatement();
		
		// sql指令
		String sql = "delete from t_user where id = 26";
		ct.executeUpdate(sql);

		
	}
	
	
	
	
	
	
	
	
	
	
	
}
