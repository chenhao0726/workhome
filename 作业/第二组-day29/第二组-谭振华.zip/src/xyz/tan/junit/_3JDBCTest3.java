package xyz.tan.junit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.junit.Test;

import xyz.tan.jdbctest.User;

public class _3JDBCTest3 {
	
	@Test
	// sql 删除
	public void delete() {
		//加连预执释
		// 加载 jar
		Connection conn = null;
		Statement ct = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			//预加载
			ct = conn.createStatement();
			//执行语句
			ct.executeUpdate("delete from t_user where id = 18");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
	}
	
	// 插入
	@Test
	public void save() throws Exception {
		// 加连预执释
		//加载驱动
		Class.forName("com.mysql.jdbc.Driver");
		// 连接sql
		Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026","root","123456");
		//  预加载sql	
		Statement ct = cn.createStatement();
		// 执行sql语句
		String sql = "insert into t_user(name,pwd,gender,age) value('js','123456',0,28)";
		ct.executeUpdate(sql);
		ct.close();
		cn.close();
	}
	// 修改
	@Test
	public void update() {
		// 加连预执释
		Connection conn = null;
		Statement ct = null;
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接 sql
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载
			ct = conn.createStatement();
			// 执行SQL语句
			String sql = "update t_user set name = 'july',age=17 where id = 26";
			ct.executeUpdate(sql);

			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	// 查询一：
	@Test
	public void queryOne() throws Exception {
		// 加连预执释
		// 加载
		Class.forName("com.mysql.jdbc.Driver");
		// 连接数据库  (url不能有空格)
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026","root","123456");
		// 预加载
		Statement ct = conn.createStatement();
		// 执行sql语句
		String sql = "select * from t_user";
		// 查询返回ResultSet集合
		ResultSet ey = ct.executeQuery(sql);
		System.out.println(ey);
//		ey.next();
//		System.out.println(ey.getInt(1));
		
		
		// 循环方式一 ---- 写字段顺序
//		while(ey.next()) {
//		System.out.print(ey.getInt(1)+"--");
//		System.out.print(ey.getString(2)+"--");
//		System.out.print(ey.getString(3)+"--");
//		System.out.print(ey.getInt(4)+"--");
//		System.out.println(ey.getInt(5)+"--");
//		}
		
		
//		// 循环方式二  ----  写字段名
//		while(ey.next()) {
//			System.out.print(ey.getInt("id")+"--");
//			System.out.print(ey.getString("name")+"--");
//			System.out.print(ey.getString("pwd")+"--");
//			System.out.print(ey.getInt("gender")+"--");
//			System.out.println(ey.getInt("age")+"--");
//		}
//		
		
		// 循环方式三  ----  将类型直接用Object-- 使用时需要向下转型
		while(ey.next()) {
			System.out.print(ey.getObject("id")+"--");
			System.out.print(ey.getObject("name")+"--");
			System.out.print(ey.getObject("pwd")+"--");
			System.out.print(ey.getObject("gender")+"--");
			System.out.println(ey.getObject("age")+"--");
		}
		
		ct.close();
		conn.close();
		

	}
	@Test
	public void queryAllByid() {
		// 加连预执释
		Connection conn = null;
		Statement ct = null;
		try {
			//加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接
			conn = DriverManager.getConnection("jdbc:mysql://localhost/day1026", "root", "123456");
			// 预加载
			ct = conn.createStatement();
			// 执行sql语句
			String sql = "select * from t_user";
			ResultSet ey = ct.executeQuery(sql);
			//调用resultSet的next()来移动指针
			// 用 list进行接收
			ArrayList arrayList = new ArrayList<User>();
		
			while(ey.next()) {
				// 将返回值传进实体类中
				User user = new User(ey.getInt(1),ey.getString(2),ey.getString(3),ey.getInt(4),ey.getInt(5));
				// 用ArayList()接收
				arrayList.add(user);
			}
			arrayList.forEach(System.out :: println);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {// 释放资源
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		
		
		
		
	}

}




















