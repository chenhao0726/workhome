package xyz.tan.daotest2.dao;

import java.util.List;

import xyz.tan.daotest2.domain._1Admin;

public interface IAdminDao {
	// 删除
	void delete(Long id);
	//插入
	void save(_1Admin ad);
	// 修改
	void update(_1Admin ad);
	// 查询一个
	_1Admin queryOneById(Long id);
	//  查询全部
	List<_1Admin> queryAll();
	
	
	
	
	
	
	
}
