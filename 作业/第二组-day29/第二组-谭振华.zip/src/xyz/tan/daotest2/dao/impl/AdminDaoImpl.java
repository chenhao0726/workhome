package xyz.tan.daotest2.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import xyz.tan.daotest2.dao.IAdminDao;
import xyz.tan.daotest2.domain._1Admin;

public class AdminDaoImpl implements IAdminDao{

	@Override
	public void delete(Long id) {
		// 加连预执释
		Connection conn = null;
		Statement ct = null;
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载执行对象
			ct = conn.createStatement();
			// sql 执行语句
			String sql = "delete from t_user where id = "+id;
			// 执行sql
			ct.executeUpdate(sql);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	}

	@Override
	public void save(_1Admin ad) {
		// 加连预执释
		Connection conn = null;
		Statement ct = null;
		try {
			//加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载执行对象
			ct = conn.createStatement();
			// sql 命令
			String sql = "insert into t_user(name,pwd,gender,age) value('"
							+ad.getName()+"','"+ad.getPwd()+"',"+ad.getGender()+","+ad.getAge()+")";
			// 执行sql
			ct.executeUpdate(sql);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
	
	}

	@Override
	// 修改
	public void update(_1Admin ad) {

		// 加连预执释
		Connection conn = null;
		Statement ct = null;
		try {
			
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载执行对象
			ct = conn.createStatement();
			// sql 命令
			String sql = "update t_user set name = '"+ad.getName()+"',pwd = '"+ad.getPwd()
							+"',gender = "+ad.getGender()+", age = "+ad.getAge()+" where id="+ad.getId();
			// 执行sql
			ct.executeUpdate(sql);
	
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
	}

	@Override
	public _1Admin queryOneById(Long id) {
		// 加连预执释
		Connection conn =  null;
		Statement ct = null;
		ResultSet ey = null;
		
		_1Admin ad = new _1Admin();
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载执行对象
			ct = conn.createStatement();
			// sql语句
			String sql = "select * from t_user where id = "+id;
			// 执行sql语句  executeQuery()返回的是set结果集
			ey = ct.executeQuery(sql);
//			System.out.println(ey);
			while(ey.next()) {
				ad.setId(ey.getLong(1));
				ad.setName(ey.getString(2));
				ad.setPwd(ey.getString(3));
				ad.setGender(ey.getInt(4));
				ad.setAge(ey.getInt(5));
			}
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ey.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}	
		
		return ad;
	}

	@Override
	public List<_1Admin> queryAll() {
		ArrayList<_1Admin> arrayList = new ArrayList<_1Admin>();
		Connection conn = null;
		Statement ct = null;
		ResultSet ey = null;
		// 加连预执释
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 连接数据库
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/day1026", "root", "123456");
			// 预加载执行对象
			ct = conn.createStatement();
			// sql命令
			String sql = "select * from t_user";
			// 执行sql
			ey = ct.executeQuery(sql);
			// 循环获取set对象
			while(ey.next()) {
				_1Admin _1Admin = new _1Admin(ey.getLong(1), ey.getString(2), ey.getString(3), ey.getInt(4), ey.getInt(5));
				// 循环一次就会将数据传入list中一次
				arrayList.add(_1Admin);
			}
			
			
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ey.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
		return arrayList;
	}

}
