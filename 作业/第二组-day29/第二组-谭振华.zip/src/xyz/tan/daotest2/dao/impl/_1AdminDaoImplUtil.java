package xyz.tan.daotest2.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import xyz.tan.daotest2.dao.IAdminDao;
import xyz.tan.daotest2.domain._1Admin;
import xyz.tan.daoutil2.DaoUtil;

public class _1AdminDaoImplUtil implements IAdminDao{

	@Override
	public void delete(Long id) {
		// 加连预执释
		Connection conn = DaoUtil._1getConnection();
		Statement ct = null;
		try {
			// 预加载执行对象
			ct = conn.createStatement();
			// sql 执行语句
			String sql = "delete from t_user where id = "+id;
			// 执行sql
			ct.executeUpdate(sql);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DaoUtil.close(null, ct, conn);
		}

		
	}

	@Override
	public void save(_1Admin ad) {
		// 加连预执释
		Connection conn = DaoUtil._1getConnection();
		Statement ct = null;
		try {
			
			// 预加载执行对象
			ct = conn.createStatement();
			// sql 命令
			String sql = "insert into t_user(name,pwd,gender,age) value('"
							+ad.getName()+"','"+ad.getPwd()+"',"+ad.getGender()+","+ad.getAge()+")";
			// 执行sql
			ct.executeUpdate(sql);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DaoUtil.close(null, ct, conn);
		}
	
	}

	@Override
	// 修改
	public void update(_1Admin ad) {

		// 加连预执释
		Connection conn = DaoUtil._1getConnection();
		Statement ct = null;
		try {
			
			// 预加载执行对象
			ct = conn.createStatement();
			// sql 命令
			String sql = "update t_user set name = '"+ad.getName()+"',pwd = '"+ad.getPwd()
							+"',gender = "+ad.getGender()+", age = "+ad.getAge()+" where id="+ad.getId();
			// 执行sql
			ct.executeUpdate(sql);
	
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DaoUtil.close(null, ct, conn);
		}
	
		
	}

	@Override
	public _1Admin queryOneById(Long id) {
		// 加连预执释
		Connection conn = DaoUtil._1getConnection();
		Statement ct = null;
		ResultSet ey = null;
		
		_1Admin ad = new _1Admin();
		try {
			
			// 预加载执行对象
			ct = conn.createStatement();
			// sql语句
			String sql = "select * from t_user where id = "+id;
			// 执行sql语句  executeQuery()返回的是set结果集
			ey = ct.executeQuery(sql);
//			System.out.println(ey);
			while(ey.next()) {
				ad.setId(ey.getLong(1));
				ad.setName(ey.getString(2));
				ad.setPwd(ey.getString(3));
				ad.setGender(ey.getInt(4));
				ad.setAge(ey.getInt(5));
			}
		
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DaoUtil.close(ey, ct, conn);
			
		}	
		
		return ad;
	}

	@Override
	public List<_1Admin> queryAll() {
		ArrayList<_1Admin> arrayList = new ArrayList<_1Admin>();
		Connection conn = DaoUtil._1getConnection();
		Statement ct = null;
		ResultSet ey = null;
		// 加连预执释
		try {
			// 预加载执行对象
			ct = conn.createStatement();
			// sql命令
			String sql = "select * from t_user";
			// 执行sql
			ey = ct.executeQuery(sql);
			// 循环获取set对象
			while(ey.next()) {
				_1Admin _1Admin = new _1Admin(ey.getLong(1), ey.getString(2), ey.getString(3), ey.getInt(4), ey.getInt(5));
				// 循环一次就会将数据传入list中一次
				arrayList.add(_1Admin);
			}
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DaoUtil.close(ey, ct, conn);
		}

		
		return arrayList;
	}

}
