package xyz.tan.daotest2;

import java.util.List;

import org.junit.Test;

import xyz.tan.daotest2.dao.IAdminDao;
import xyz.tan.daotest2.dao.impl._1AdminDaoImplUtil;
import xyz.tan.daotest2.domain._1Admin;



public class TestDao2 {
	
	IAdminDao daoImpl = new _1AdminDaoImplUtil();
	
	@Test
	public void testDelete(){
		daoImpl.delete(29L);
	}
	
	@Test
	public void testSave() {
		daoImpl.save(new _1Admin(null, "habara", "123456", 1, 21));
	}
	
	@Test
	public void testUpdate(){
		daoImpl.update(new _1Admin(24L, "takagi", "123456", 0, 21));
	}
	 
	@Test
	public void testQueryOne() {
		System.out.println(daoImpl.queryOneById(34L));
	}
	
	@Test
	public void testQueryAll() {
		List<_1Admin> queryAll = daoImpl.queryAll();
		queryAll.forEach(System.out :: println);
	}
	
	
	
	
	
}
