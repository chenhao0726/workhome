package xyz.tan.daotest2;

import java.util.List;

import org.junit.Test;

import xyz.tan.daotest2.dao.IAdminDao;
import xyz.tan.daotest2.dao.impl.AdminDaoImpl;
import xyz.tan.daotest2.domain._1Admin;



public class TestDao {
	IAdminDao daoImpl = new AdminDaoImpl();
	
	@Test
	public void testDelete(){
		daoImpl.delete(28L);
	}
	
	@Test
	public void testSave() {
		daoImpl.save(new _1Admin(null, "habara", "123456", 1, 21));
	}
	
	@Test
	public void testUpdate(){
		daoImpl.update(new _1Admin(29L, "takagi", "123456", 0, 21));
	}
	 
	@Test
	public void testQueryOne() {
		System.out.println(daoImpl.queryOneById(34L));
	}
	
	@Test
	public void testQueryAll() {
		List<_1Admin> queryAll = daoImpl.queryAll();
		queryAll.forEach(System.out :: println);
	}
	
	
	
	
	
}
