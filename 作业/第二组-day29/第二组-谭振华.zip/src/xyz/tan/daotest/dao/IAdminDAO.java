package xyz.tan.daotest.dao;

import java.util.List;

import xyz.tan.daotest.domain.Admin;

// 导包里装的是连接数据库的接口
public interface IAdminDAO {
	// 删除
	void delete(Long id);
	//插入
	
	void save(Admin ad);
	// 修改
	void update(Admin ad);
	//查询一个通过id
	Admin queryOneById(Long id);
	// 查询所有
	List<Admin> queryAllById();
}
