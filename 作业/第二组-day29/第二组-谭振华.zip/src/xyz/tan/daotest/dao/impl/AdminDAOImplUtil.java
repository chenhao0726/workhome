package xyz.tan.daotest.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import xyz.tan.daotest.dao.IAdminDAO;
import xyz.tan.daotest.domain.Admin;
import xyz.tan.daoutil.DAOUtil;

public class AdminDAOImplUtil implements IAdminDAO{

	@Override
	public void delete(Long id) {
		Connection conn = DAOUtil.getConnection();
		Statement ct= null;
		// 加连预执释
		try {
			// 预加载数据库
			ct= conn.createStatement();
			// sql指令
			String sql = "delete from t_user where id = "+id;
			ct.executeUpdate(sql);
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DAOUtil.close(null, ct, conn);
		}
		
	}

	@Override
	// 插入语句
	public void save(Admin ad){
		//加连预执释
		Connection conn = DAOUtil.getConnection();
		Statement ct = null;
		// 加载
		try {
			// 预加载数据库
			ct = conn.createStatement();
			// sql指令  拼接时有字符串要注意加上''
			String sql = "insert into t_user (name,pwd,gender,age)value('"+ad.getName()+"','"+ad.getPwd()+"',"+ad.getGender()+","+ad.getAge()+")";
			// 执行sql
			ct.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DAOUtil.close(null, ct, conn);
		}
	
		
	}

	@Override
	// 修改
	public void update(Admin ad) {
		// 加连预执释(已经重构)
		Connection conn = DAOUtil.getConnection();
		Statement ct = null;
		try {
			// 预加载
			ct = conn.createStatement();
			//sql命令
			String sql = "update t_user set `name`='"+ad.getName()+"',age="+ad.getAge()+" where id="+ad.getId();
			ct.executeUpdate(sql);
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DAOUtil.close(null, ct, conn);
		}
		
	}

	@Override
	// 查询一个
	public Admin queryOneById(Long id) {
		Connection conn = DAOUtil.getConnection();
		Statement ct = null;
		ResultSet ey = null;
		Admin admin = new Admin();
		try {
			// 加 连 预执释
			
			// 预加载sql
			ct = conn.createStatement();
			// sql 查询语句
			String sql = "select * from t_user where id = "+id;
			// 执行sql语句  得到-resultSet  结果集  getInt()是set集合中得方法获取到对象
			ey = ct.executeQuery(sql);
//			System.out.println(ey);
			while(ey.next()) {
				admin.setId(ey.getLong(1));
				admin.setName(ey.getString(2));
				admin.setPwd(ey.getString(3));
				admin.setGender(ey.getInt(4));
				admin.setAge(ey.getInt(5));
		
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DAOUtil.close(ey, ct, conn);
		}
		return admin;

	}

	@Override
	public List<Admin> queryAllById() {
		// 加连预执释
		Connection conn = DAOUtil.getConnection();
		Statement ct = null;
		ResultSet ey = null;
		//用ArrayList接收
		ArrayList<Admin> arrayList = new ArrayList<Admin>();
		try {
			// 预加载
			ct = conn.createStatement();
			// sql语句
			String sql = "select * from t_user";
			ey = ct.executeQuery(sql);
			//循环获取soultSet  是set的集合但是不能用迭代器
			while(ey.next()) {
				// 将值放到实体类中
				Admin admin = new Admin(ey.getLong(1), ey.getString(2), ey.getString(3), ey.getInt(4), ey.getInt(5));
				// 将值传入列表
				arrayList.add(admin);
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DAOUtil.close(ey, ct, conn);
		
		}
		return arrayList;
	
	}

}
