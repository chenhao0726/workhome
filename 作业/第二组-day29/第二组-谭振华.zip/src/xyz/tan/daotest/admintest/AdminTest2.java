package xyz.tan.daotest.admintest;

import java.util.List;

import org.junit.Test;

import xyz.tan.daotest.dao.IAdminDAO;
import xyz.tan.daotest.dao.impl.AdminDAOImpl;
import xyz.tan.daotest.dao.impl.AdminDAOImplUtil;
import xyz.tan.daotest.domain.Admin;

public class AdminTest2 {
	// 传入对象并声明为全局方便调用
	public IAdminDAO daoImpl = new AdminDAOImplUtil();
	@ Test
	public void deleteTest() {
		daoImpl.delete(30L);
	}
	@Test
	public void saveTest() {
		daoImpl.save(new Admin(null,"jojota", "123456", 0, 56));
	}
	@Test
	public void updateTest() {
		daoImpl.update(new Admin(33L,"yuiko", "123456", 0, 17));
	}
	@Test
	public void queryOne() {
		System.out.println(daoImpl.queryOneById(27L));
	}
	@Test
	public void queryAllById() {
//		System.out.println(daoImpl.quueryAllById());
		List<Admin> AllById = daoImpl.queryAllById();
		AllById.forEach(System.out :: println);
	}

}
