package xyz.tan.daoutil;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


public class DAOUtil {
	
	 // 加载驱动及连接sql
	
	 private static String url;
	 private static String driver;
	 private static String userName;
	 private static String password;

	static {
		// 创建properties对象
		 Properties properties = new Properties();
		// 获取properties流    类加载器.getClassLoader()  将result（结果） as（到） stream（流）getResourceAsStream
		 InputStream ras = DAOUtil.class.getClassLoader().getResourceAsStream("jdbcutil.properties");
		
		try {	
			// 载入文件
			properties.load(ras);
			url = properties.getProperty("jdbctest.url");// 测试key，所以名字不一样
			driver = properties.getProperty("jdbcutil.driver");
			userName = properties.getProperty("jdbcutil.userName");
			password = properties.getProperty("jdbcutil.password");
			
			
			
			// 加载驱动
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static Connection getConnection() {
		// 连接数据库
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
		
	}
	
	
	
	
	
	
	
	// 释放资源
	public static void close(ResultSet ey ,Statement ct , Connection conn ) {
		if(ey != null) {
			try {
				ey.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(ct != null) {
			try {
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
}
